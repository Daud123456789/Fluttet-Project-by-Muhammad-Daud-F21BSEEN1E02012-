package com.example.flutter_attendance_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
