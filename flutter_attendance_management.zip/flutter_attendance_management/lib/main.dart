import 'dart:convert';
import 'package:flutter/material.dart';

void main() {
  runApp(AttendanceManagementApp());
}

class AttendanceManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AttendanceManagementScreen(),
    );
  }
}

class AttendanceManagementScreen extends StatefulWidget {
  @override
  _AttendanceManagementScreenState createState() =>
      _AttendanceManagementScreenState();
}

class _AttendanceManagementScreenState
    extends State<AttendanceManagementScreen> {
  List<Employee> employees = [
    Employee(name: 'Rubab Jan'),
    Employee(name: 'Bqkhtawar jan'),
    Employee(name: 'Sana jan'),
  ];

  List<AttendanceRecord> attendanceRecords = [];

  @override
  void initState() {
    super.initState();
    _loadAttendanceRecords();
  }

  void _loadAttendanceRecords() {
    // Load attendance records from storage (in-memory storage for demonstration)
    final storedData = '''
    [
      {"employee": {"name": "Rubab Fatima"}, "date": "2022-04-12"},
      {"employee": {"name": "bakhtawar bilal maher"}, "date": "2022-04-12"}
    ]
    ''';

    List<dynamic> jsonData = jsonDecode(storedData);
    attendanceRecords = jsonData
        .map((record) => AttendanceRecord.fromJson(record))
        .toList();
  }

  void _saveAttendanceRecords() {
    // Save attendance records to storage (in-memory storage for demonstration)
    final dataToStore = jsonEncode(
      attendanceRecords.map((record) => record.toJson()).toList(),
    );
    print('Saving data: $dataToStore');
    // You can store the data to your preferred storage mechanism here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Management'),
      ),
      body: ListView.builder(
        itemCount: employees.length,
        itemBuilder: (context, index) {
          final employee = employees[index];
          final isPresent = attendanceRecords.any((record) =>
              record.employee.name == employee.name &&
              record.date == DateTime.now().toString().split(' ')[0]);

          return ListTile(
            title: Text(employee.name),
            trailing: Icon(
              isPresent ? Icons.check_circle_outline : Icons.error_outline,
              color: isPresent ? Colors.green : Colors.red,
            ),
            onTap: () {
              _toggleAttendance(employee);
            },
          );
        },
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () {
              _addAttendance();
            },
            tooltip: 'Add Attendance',
            child: Icon(Icons.add),
          ),
          SizedBox(height: 16),
          FloatingActionButton(
            onPressed: () {
              _cancelAttendance();
            },
            tooltip: 'Cancel Attendance',
            child: Icon(Icons.cancel),
          ),
        ],
      ),
    );
  }

  void _toggleAttendance(Employee employee) {
    final isPresent = attendanceRecords.any((record) =>
        record.employee.name == employee.name &&
        record.date == DateTime.now().toString().split(' ')[0]);

    setState(() {
      if (isPresent) {
        attendanceRecords.removeWhere((record) =>
            record.employee.name == employee.name &&
            record.date == DateTime.now().toString().split(' ')[0]);
      } else {
        attendanceRecords.add(AttendanceRecord(
          employee: employee,
          date: DateTime.now().toString().split(' ')[0],
        ));
      }
    });
    _saveAttendanceRecords();
  }

  void _addAttendance() {
    final selectedEmployee = employees.first; // Replace with actual selection logic
    attendanceRecords.add(AttendanceRecord(
      employee: selectedEmployee,
      date: DateTime.now().toString().split(' ')[0],
    ));
    _saveAttendanceRecords();
    setState(() {});
  }

  void _cancelAttendance() {
    final selectedEmployee = employees.first; // Replace with actual selection logic
    attendanceRecords.removeWhere((record) =>
        record.employee.name == selectedEmployee.name &&
        record.date == DateTime.now().toString().split(' ')[0]);
    _saveAttendanceRecords();
    setState(() {});
  }
}

class Employee {
  final String name;

  Employee({required this.name});
}

class AttendanceRecord {
  final Employee employee;
  final String date;

  AttendanceRecord({required this.employee, required this.date});

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) {
    return AttendanceRecord(
      employee: Employee(name: json['employee']['name']),
      date: json['date'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'employee': {'name': employee.name},
      'date': date,
    };
  }
}
